import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Dataset Load Karna
df = pd.read_csv("data/credit_data.csv")

print("--- DATASET PREVIEW ---")
print(df.head())

print("\n--- DATASET INFO ---")
print(df.info())

print("\n--- MISSING VALUES CHECK ---")
print(df.isnull().sum())

# 2. Target Variable Distribution (Class Imbalance Check)
print("\n--- TARGET VARIABLE COUNTS ---")
target_counts = df['credit_risk'].value_counts()
target_pct = df['credit_risk'].value_counts(normalize=True) * 100

print(f"Good Credit (0): {target_counts[0]} ({target_pct[0]:.2f}%)")
print(f"Bad Credit / Default (1): {target_counts[1]} ({target_pct[1]:.2f}%)")

# Visualizing Target Imbalance
plt.figure(figsize=(6, 4))
sns.countplot(x='credit_risk', data=df, palette='Set2')
plt.title('Target Variable Distribution (0 = Good, 1 = Default)')
plt.xlabel('Credit Risk')
plt.ylabel('Count')
plt.show()

# 3. Key Numerical Features vs Target Analysis
plt.figure(figsize=(12, 4))

plt.subplot(1, 3, 1)
sns.boxplot(x='credit_risk', y='credit_amount', data=df)
plt.title('Credit Amount vs Risk')

plt.subplot(1, 3, 2)
sns.boxplot(x='credit_risk', y='duration_in_month', data=df)
plt.title('Loan Duration (Months) vs Risk')

plt.subplot(1, 3, 3)
sns.boxplot(x='credit_risk', y='age', data=df)
plt.title('Age vs Risk')

plt.tight_layout()
plt.show()